
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $vegetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vegetables): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h1><?php echo e($vegetables->name); ?></h1><br />
  <h1><?php echo e($vegetables->price); ?></h1>
  <p>This is the index page
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Api\resources\views/pages/store.blade.php ENDPATH**/ ?>