
<?php $__env->startSection('content'); ?>
  <h1><?php echo e($title); ?></h1>
  <p>This is the index page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Api\resources\views/pages/index.blade.php ENDPATH**/ ?>