

Hello



<form action="/create" method="post">


   


    Name<input type="text" name="name" id="name"><br><br>
    Price<input type="number" id="price" name="price"><br><br>
    Select your type of Order:<input type="radio" id="typeOrder" name="typeOrder" value="online">
    <label for="online">Online</label>
    <input type="radio"  name="typeOrder" id="typeOrder"value="buy">
   <label for="buy">Buy from shop</label><br><br>
    Amount<input type="number" name="amount" id="amount"/><br><br>
    <input type="submit" value="order">

       

</form>



