<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class Mycontroller extends Controller
{
   public function index(){
      $title="Welcome beginners programming";
    //  return view('pages.index',compact('title'));
    return view('pages.index')->with('title',$title);
    }



        public function store(Request $request)
    {
        $vegetables = DB::select('select * from vegetables');
return view('pages.store',['vegetables'=>$vegetables]);

        //
    }

       public function insert(Request $request)
    {
       $name = $request->input('name');
       $amount = $request->input('amount');
       $typeOrder = $request->input('typeOrder');
       $price = $request->input('price');

       $data=array("name"=>$name,"amount"=>$amount,"typeOrder"=>$typeOrder,"price"=>$price);
DB::table("vegetables")->insert($data);

echo"ok success";
        //
    }
}
