@extends('layouts.app')
@section('content')
  <h1>{{$hh}}</h1>
  <p>This is the index page
@endsection
