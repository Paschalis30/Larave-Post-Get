@extends('layouts.app')
@section('content')
@foreach ($vegetables as $vegetables)
  <h1>{{$vegetables->name}}</h1><br />
  <h1>{{$vegetables->price}}</h1>
  <p>This is the index page
    @endforeach
@endsection
